# TestDelta 홍보 키트

공개 소개: https://hyscodebase.github.io/testdelta/
Marketplace: https://github.com/marketplace/actions/testdelta-test-quality
공개 버전: v0.1.0-alpha.4 (초기 알파)
저장소: https://github.com/hyscodebase/testdelta
Action 안내: https://github.com/hyscodebase/testdelta/blob/main/docs/action.md

copy/launch-kit.md에 한영 소개·LinkedIn·X·커뮤니티·Show HN 초안이 있습니다.
branding/social-card.png는 1200×630 공유 이미지이며 원본 SVG도 포함합니다.
demo/index.html은 오프라인에서 열 수 있는 정적 소개/사례 페이지입니다. 이 페이지가 Python 테스트를 실행하는 것은 아닙니다.

Marketplace 등록과 설치 버전은 공개 페이지에서 확인했습니다. 이 키트는 외부 SNS/커뮤니티에 게시물을 자동으로 보내지 않습니다.
자료와 이미지의 라이선스는 LICENSE를 확인하세요. 개인 DB·raw 결과·환경 파일은 포함하지 않습니다.
